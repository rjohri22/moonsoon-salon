<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('css'); ?>
<style>
    .h-p-bold-gray{
        color: #808080; font-weight: 500; padding-left: 10px;
    }
    .h-bold-gray{
        color: #696969; font-weight: 600;
    }
</style>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('js'); ?>
<?php /**PATH /home/ypcsxpok/public_html/app/resources/views/admin/layout.blade.php ENDPATH**/ ?>