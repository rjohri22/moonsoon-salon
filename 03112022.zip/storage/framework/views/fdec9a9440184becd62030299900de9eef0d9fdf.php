<?php $__env->startSection('content'); ?>
<!-- adminx-content-aside -->
<div class="adminx-content">
  <!-- <div class="adminx-aside">
        </div> -->
  <div class="adminx-main-content">
    <div class="container-fluid">
      <!-- BreadCrumb -->
      <div class="pb-3">
        <h1>Dashboard</h1>
      </div>

      <div class="row">


        <div class="col-md-6 col-lg-3 d-flex">
          <div class="card border-0 bg-primary text-white text-center mb-grid w-100">
            <div class="d-flex flex-row align-items-center h-100">
              <div class="card-icon d-flex align-items-center h-100 justify-content-center">
                <i class="fa fa-line-chart fa-2x" aria-hidden="true"></i>
              </div>
              <div class="card-body">
                <div class="card-info-title">Total Brands</div>
                <h3 class="card-title mb-0">
                  <?php echo e($brand); ?>

                </h3>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-3 d-flex">
          <div class="card border-0 bg-success text-white text-center mb-grid w-100">
            <div class="d-flex flex-row align-items-center h-100">
              <div class="card-icon d-flex align-items-center h-100 justify-content-center">
                <i class="fa fa-line-chart fa-2x" aria-hidden="true"></i>
              </div>
              <div class="card-body">
                <div class="card-info-title">Total Service</div>
                <h3 class="card-title mb-0">
                  <?php echo e($service); ?>

                </h3>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-3 d-flex">
          <div class="card border-0 bg-success text-white text-center mb-grid w-100">
            <div class="d-flex flex-row align-items-center h-100">
              <div class="card-icon d-flex align-items-center h-100 justify-content-center">
              <i class="fa fa-line-chart fa-2x" aria-hidden="true"></i>
              </div>
              <div class="card-body">
                <div class="card-info-title">Total Items</div>
                <h3 class="card-title mb-0">
                  <?php echo e($item); ?>

                </h3>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-3 d-flex">
          <div class="card border-0 bg-primary text-white text-center mb-grid w-100">
            <div class="d-flex flex-row align-items-center h-100">
              <div class="card-icon d-flex align-items-center h-100 justify-content-center">
                <!-- <i data-feather="credit-card"></i> -->
                <i class="fa fa-inr fa-2x" aria-hidden="true"></i>
              </div>
              <div class="card-body">
                <div class="card-info-title">Today Received Payment</div>
                <h3 class="card-title mb-0">
                  <!-- ₹ 11,654 -->
                  ₹ <?php echo e(number_format($payment,2)); ?>

                </h3>
              </div>
            </div>
          </div>
        </div>
        
        
      </div>
      <div class="row">
        <div class="col-md-12">
          <canvas id="myChart" width="400" height="400"></canvas>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js"></script>
  <script>
  // const ctx = document.getElementById('myChart');
    var orderDataSet = JSON.parse("<?php echo e(json_encode($toReturn['order_dataset'])); ?>");
    console.log("orderDataSet",orderDataSet);
    var ctx = document.getElementById("myChart");
    var myLineChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        datasets: [{
          label: "Earing",
          lineTension: 0.3,
          backgroundColor: "rgba(78, 115, 223, 0.05)",
          borderColor: "rgba(78, 115, 223, 1)",
          pointRadius: 3,
          pointBackgroundColor: "rgba(78, 115, 223, 1)",
          pointBorderColor: "rgba(78, 115, 223, 1)",
          pointHoverRadius: 3,
          pointHoverBackgroundColor: "rgba(78, 115, 223, 1)",
          pointHoverBorderColor: "rgba(78, 115, 223, 1)",
          pointHitRadius: 10,
          pointBorderWidth: 2,
          // data: [0,0,635,0,0,0,0,0,0,0,0,0],
          data: orderDataSet,
          // data: [0, 10000, 5000, 15000, 10000, 20000, 15000, 25000, 20000, 30000, 25000, 40000],
        }],
      },
      options: {
        maintainAspectRatio: false,
        layout: {
          padding: {
            left: 10,
            right: 25,
            top: 25,
            bottom: 0
          }
        },
        scales: {
          xAxes: [{
            time: {
              unit: 'date'
            },
            gridLines: {
              display: false,
              drawBorder: false
            },
            ticks: {
              maxTicksLimit: 7
            }
          }],
          yAxes: [{
            ticks: {
              maxTicksLimit: 5,
              padding: 10,
              // Include a dollar sign in the ticks
              callback: function(value, index, values) {
                return  number_format(value);
              }
            },
            gridLines: {
              color: "rgb(234, 236, 244)",
              zeroLineColor: "rgb(234, 236, 244)",
              drawBorder: false,
              borderDash: [2],
              zeroLineBorderDash: [2]
            }
          }],
        },
        legend: {
          display: false
        },
        tooltips: {
          backgroundColor: "rgb(255,255,255)",
          bodyFontColor: "#858796",
          titleMarginBottom: 10,
          titleFontColor: '#6e707e',
          titleFontSize: 14,
          borderColor: '#dddfeb',
          borderWidth: 1,
          xPadding: 15,
          yPadding: 15,
          displayColors: false,
          intersect: false,
          mode: 'index',
          caretPadding: 10,
          callbacks: {
            label: function(tooltipItem, chart) {
              var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
              return datasetLabel + ': ' + number_format(tooltipItem.yLabel);
            }
          }
        }
      }
    });
    
  </script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ypcsxpok/public_html/app/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>